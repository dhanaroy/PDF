After generating the reports. Copy the webjars folder to \Result\ location. 
if you are not like this format you may continue using the old format refer to other zip file 